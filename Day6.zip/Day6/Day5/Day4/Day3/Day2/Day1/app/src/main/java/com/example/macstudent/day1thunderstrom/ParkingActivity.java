package com.example.macstudent.day1thunderstrom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class ParkingActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {


    RadioButton rdoHalf, rdoOne, rdoTwo, rdoThree;
    TextView txtAmount, txtDateTime;
    int parkingRate[] = {5,10,20,35};
    String lots[] = {"A","B","C","D","E"};
    String spots[] = {"1", "2", "3", "4", "5"};
    String paymentMethods[] = {"Debit", "Visa", "Master Card", "American Express", "Cash"};

    int logos[] = {R.drawable.img_bmw, R.drawable.img_audi, R.drawable.img_mercedes, R.drawable.img_jaguar, R.drawable.img_lexus};
    String companyNames[] = {"BMW", "Audi", "Mercedes", "Jaguar", "Lexus"};

    Spinner spinLot, spinSpot, spinPayment, spinCompany;

    String lot, spot, carPlate, payment, dateTime, company;
    int amount;
    Button btnSave;
    EditText edtCarPlate;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking);

        rdoHalf = (RadioButton) findViewById(R.id.rdoHalfHour);
        rdoHalf.setOnClickListener(this);

        rdoOne = (RadioButton) findViewById(R.id.rdoOneHour);
        rdoOne.setOnClickListener(this);

        rdoTwo = (RadioButton) findViewById(R.id.rdoTwoHour);
        rdoTwo.setOnClickListener(this);

        rdoThree = (RadioButton) findViewById(R.id.rdoThreeHour);
        rdoThree.setOnClickListener(this);

        txtAmount = (TextView) findViewById(R.id.txtAmount);
        txtAmount.setOnClickListener(this);

        txtDateTime = (TextView) findViewById(R.id.txtDateTime);
        Date dt = Calendar.getInstance().getTime();
        txtDateTime.setText(dt.toString());

        spinLot = (Spinner) findViewById(R.id.spinLot);
        ArrayAdapter adaptLot = new ArrayAdapter(this, android.R.layout.simple_spinner_item, lots);
        adaptLot.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinLot.setAdapter(adaptLot);
        spinLot.setOnItemSelectedListener(this);

        spinSpot = (Spinner) findViewById(R.id.spinSpot);
        ArrayAdapter adaptSpot = new ArrayAdapter(this, android.R.layout.simple_spinner_item, spots);
        adaptSpot.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinSpot.setAdapter(adaptSpot);
        spinSpot.setOnItemSelectedListener(this);

        spinPayment = (Spinner) findViewById(R.id.spinPayment);
        ArrayAdapter adaptPayment = new ArrayAdapter(this, android.R.layout.simple_spinner_item, paymentMethods);
        adaptPayment.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinPayment.setAdapter(adaptPayment);
        spinPayment.setOnItemSelectedListener(this);

        spinCompany = (Spinner) findViewById(R.id.spinCompany);
        CarAdapter carAdapter = new CarAdapter(getApplicationContext(), logos, companyNames);
        spinCompany.setAdapter(carAdapter);
        spinCompany.setOnItemSelectedListener(this);

        btnSave = (Button) findViewById(R.id.btnSave);
        btnSave.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if(rdoHalf.isChecked())
        {
            txtAmount.setText("$" +String.valueOf(parkingRate[0]));
        }

        else if(rdoOne.isChecked())
        {
            txtAmount.setText("$" +String.valueOf(parkingRate[1]));
        }

        else if(rdoTwo.isChecked())
        {
            txtAmount.setText("$" +String.valueOf(parkingRate[2]));
        }

        else if(rdoThree.isChecked())
        {
            txtAmount.setText("$" +String.valueOf(parkingRate[3]));
        }

        if(view.getId() == btnSave.getId()) {
            dateTime = txtDateTime.getText().toString();
            edtCarPlate = (EditText) findViewById(R.id.edtCarPlate);
            carPlate = edtCarPlate.getText().toString();
            String strAmount = txtAmount.getText().toString();
            strAmount = strAmount.substring(1);
            amount = Integer.parseInt(strAmount);

            SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("CarPlate", carPlate);
            edit.putString("Company", company);
            edit.putInt("Amount", amount);
            edit.putString("DateTime", dateTime);
            edit.putString("Lot", lot);
            edit.putString("Spot", spot);
            edit.putString("Payment", payment);
            edit.commit();

            Intent receiptIntent = new Intent(getApplicationContext(), ReceiptActivity.class);
            startActivity(receiptIntent);

        }


    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

        if (adapterView.getId() == spinLot.getId())
        {
            Toast.makeText(this, lots[position], Toast.LENGTH_LONG).show();
            lot = lots[position];
        }
        else if (adapterView.getId() == spinSpot.getId())
        {
            Toast.makeText(this, spots[position], Toast.LENGTH_LONG).show();
            spot = spots[position];
        }
        else if (adapterView.getId() == spinPayment.getId())
        {
            Toast.makeText(this, paymentMethods[position], Toast.LENGTH_LONG).show();
            payment = paymentMethods[position];
        }
        else if(adapterView.getId() == spinCompany.getId())
        {
            company = companyNames[position];
            Toast.makeText(this, companyNames[position], Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
